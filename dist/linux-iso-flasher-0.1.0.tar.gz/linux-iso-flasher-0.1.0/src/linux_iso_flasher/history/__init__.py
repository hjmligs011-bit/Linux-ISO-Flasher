"""Histórico local de operações."""
